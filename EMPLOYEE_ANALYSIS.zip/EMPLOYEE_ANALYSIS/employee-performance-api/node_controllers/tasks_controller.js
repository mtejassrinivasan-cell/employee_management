const db = require("../config/db").promise();

// ==========================================
// 1. GET: Retrieve tasks
// ==========================================
exports.getAllTasks = async (req, res) => {
    try {
        const { employee_id, project_id, status, priority } = req.query;
        let query = `
            SELECT t.*, 
                   CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                   p.project_name
            FROM tasks t
            LEFT JOIN employees e ON t.employee_id = e.id
            LEFT JOIN projects p ON t.project_id = p.id
            WHERE 1=1
        `;
        const params = [];

        if (employee_id) {
            query += " AND t.employee_id = ?";
            params.push(employee_id);
        }
        if (project_id) {
            query += " AND t.project_id = ?";
            params.push(project_id);
        }
        if (status) {
            query += " AND t.status = ?";
            params.push(status);
        }
        if (priority) {
            query += " AND t.priority = ?";
            params.push(priority);
        }

        query += " ORDER BY t.id DESC";

        const [rows] = await db.query(query, params);
        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

exports.getTaskById = async (req, res) => {
    try {
        const { id } = req.params;
        const query = `
            SELECT t.*, 
                   CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                   p.project_name
            FROM tasks t
            LEFT JOIN employees e ON t.employee_id = e.id
            LEFT JOIN projects p ON t.project_id = p.id
            WHERE t.id = ?
        `;
        const [rows] = await db.query(query, [id]);

        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: `Task with id ${id} not found` });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 2. POST: Create a new task
// ==========================================
exports.createTask = async (req, res) => {
    try {
        const { title, description, employee_id, project_id, priority, status, due_date } = req.body;

        if (!title) {
            return res.status(400).json({ success: false, message: "title is required" });
        }

        const sql = `INSERT INTO tasks 
            (title, description, employee_id, project_id, priority, status, due_date) 
            VALUES (?, ?, ?, ?, ?, ?, ?)`;

        const [result] = await db.query(sql, [
            title,
            description || null,
            employee_id || null,
            project_id || null,
            priority || "Medium",
            status || "Pending",
            due_date || null
        ]);

        const [newRecord] = await db.query("SELECT * FROM tasks WHERE id = ?", [result.insertId]);

        res.location(`/api/tasks/${result.insertId}`);
        res.status(201).json({
            success: true,
            message: "Task created successfully",
            data: newRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 3. PUT: Full replacement/update of task
// ==========================================
exports.updateTaskFull = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description, employee_id, project_id, priority, status, due_date } = req.body;

        if (!title) {
            return res.status(400).json({
                success: false,
                message: "PUT requires all entity fields. title is required."
            });
        }

        const [existing] = await db.query("SELECT id FROM tasks WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Task with id ${id} not found` });
        }

        const sql = `UPDATE tasks SET 
            title = ?, description = ?, employee_id = ?, project_id = ?, 
            priority = ?, status = ?, due_date = ?
            WHERE id = ?`;

        await db.query(sql, [
            title,
            description || null,
            employee_id || null,
            project_id || null,
            priority || "Medium",
            status || "Pending",
            due_date || null,
            id
        ]);

        const [updatedRecord] = await db.query("SELECT * FROM tasks WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: "Task fully updated successfully (PUT)",
            data: updatedRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 4. PATCH: Partial update of task
// ==========================================
exports.updateTaskPartial = async (req, res) => {
    try {
        const { id } = req.params;
        const fields = req.body;

        if (!fields || Object.keys(fields).length === 0) {
            return res.status(400).json({ success: false, message: "Provide at least one field to update" });
        }

        const [existing] = await db.query("SELECT * FROM tasks WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Task with id ${id} not found` });
        }

        const allowedColumns = ["title", "description", "employee_id", "project_id", "priority", "status", "due_date"];
        const updates = [];
        const values = [];

        for (const [key, value] of Object.entries(fields)) {
            if (allowedColumns.includes(key)) {
                updates.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (updates.length === 0) {
            return res.status(400).json({ success: false, message: "No valid fields provided for update" });
        }

        values.push(id);
        const sql = `UPDATE tasks SET ${updates.join(", ")} WHERE id = ?`;

        await db.query(sql, values);

        const [updatedRecord] = await db.query("SELECT * FROM tasks WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: "Task partially updated successfully (PATCH)",
            updated_fields: Object.keys(fields),
            data: updatedRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 5. DELETE: Remove task by ID
// ==========================================
exports.deleteTask = async (req, res) => {
    try {
        const { id } = req.params;
        const [existing] = await db.query("SELECT * FROM tasks WHERE id = ?", [id]);

        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Task with id ${id} not found` });
        }

        await db.query("DELETE FROM tasks WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: `Task with id ${id} deleted successfully`,
            deleted_task: existing[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 6. HEAD: Return headers only
// ==========================================
exports.headAllTasks = async (req, res) => {
    try {
        const [[countResult]] = await db.query("SELECT COUNT(*) AS total FROM tasks");
        res.set({
            "Content-Type": "application/json; charset=utf-8",
            "X-Total-Count": countResult.total,
            "X-Resource-Type": "Collection",
            "X-Entity": "tasks"
        });
        res.status(200).end();
    } catch (err) {
        res.status(500).end();
    }
};

exports.headTaskById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query("SELECT id, updated_at FROM tasks WHERE id = ?", [id]);

        if (rows.length === 0) {
            return res.status(404).end();
        }

        res.set({
            "Content-Type": "application/json; charset=utf-8",
            "X-Resource-ID": id,
            "X-Entity": "tasks",
            "Last-Modified": new Date(rows[0].updated_at || Date.now()).toUTCString()
        });
        res.status(200).end();
    } catch (err) {
        res.status(500).end();
    }
};

// ==========================================
// 7. OPTIONS: Describe permitted methods
// ==========================================
exports.optionsCollection = (req, res) => {
    res.set({
        "Allow": "GET, POST, HEAD, OPTIONS",
        "Access-Control-Allow-Methods": "GET, POST, HEAD, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    });
    res.status(204).end();
};

exports.optionsItem = (req, res) => {
    res.set({
        "Allow": "GET, PUT, PATCH, DELETE, HEAD, OPTIONS",
        "Access-Control-Allow-Methods": "GET, PUT, PATCH, DELETE, HEAD, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    });
    res.status(204).end();
};
