const db = require("../config/db").promise();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// ==========================================
// 1. User Login & Token Generation
// ==========================================
exports.login = async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                message: "Please provide both username and password"
            });
        }

        const [users] = await db.query(`
            SELECT u.*, 
                   e.first_name, e.last_name, e.department, e.position, e.email
            FROM users u
            LEFT JOIN employees e ON u.employee_id = e.id
            WHERE u.username = ?
        `, [username]);

        if (users.length === 0) {
            return res.status(401).json({
                success: false,
                message: "Invalid credentials: User not found"
            });
        }

        const user = users[0];
        const isMatch = await bcrypt.compare(password, user.password_hash);

        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: "Invalid credentials: Password incorrect"
            });
        }

        const payload = {
            id: user.id,
            employee_id: user.employee_id,
            username: user.username,
            role: user.role
        };

        const token = jwt.sign(
            payload,
            process.env.JWT_SECRET || "super_secret_employee_portal_jwt_key_2026",
            { expiresIn: process.env.JWT_EXPIRES_IN || "24h" }
        );

        res.status(200).json({
            success: true,
            message: "Authentication successful",
            token: token,
            user: {
                id: user.id,
                employee_id: user.employee_id,
                username: user.username,
                role: user.role,
                full_name: user.first_name ? `${user.first_name} ${user.last_name}` : user.username,
                department: user.department,
                position: user.position,
                email: user.email
            }
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 2. User Registration (Admin / HR)
// ==========================================
exports.register = async (req, res) => {
    try {
        const { username, password, role, employee_id } = req.body;

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                message: "username and password are required"
            });
        }

        const [existing] = await db.query("SELECT id FROM users WHERE username = ?", [username]);
        if (existing.length > 0) {
            return res.status(409).json({
                success: false,
                message: `User with username '${username}' already exists`
            });
        }

        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(password, salt);

        const [result] = await db.query(
            "INSERT INTO users (employee_id, username, password_hash, role) VALUES (?, ?, ?, ?)",
            [employee_id || null, username, hash, role || "Employee"]
        );

        res.status(201).json({
            success: true,
            message: "User registered successfully",
            user: {
                id: result.insertId,
                username,
                role: role || "Employee",
                employee_id: employee_id || null
            }
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 3. Current User Profile
// ==========================================
exports.getMe = async (req, res) => {
    try {
        const [users] = await db.query(`
            SELECT u.id, u.employee_id, u.username, u.role, u.created_at,
                   e.first_name, e.last_name, e.department, e.position, e.email, e.salary, e.hire_date
            FROM users u
            LEFT JOIN employees e ON u.employee_id = e.id
            WHERE u.id = ?
        `, [req.user.id]);

        if (users.length === 0) {
            return res.status(404).json({ success: false, message: "User not found" });
        }

        // Also fetch project memberships and roles
        let projects = [];
        if (users[0].employee_id) {
            const [projRows] = await db.query(`
                SELECT p.id as project_id, p.project_name, pm.project_role
                FROM project_members pm
                JOIN projects p ON pm.project_id = p.id
                WHERE pm.employee_id = ?
            `, [users[0].employee_id]);
            projects = projRows;
        }

        res.status(200).json({
            success: true,
            user: users[0],
            assigned_projects: projects
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};
