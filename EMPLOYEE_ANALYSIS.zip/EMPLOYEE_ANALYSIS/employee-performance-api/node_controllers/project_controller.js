const db = require("../config/db").promise();

// ==========================================
// 1. GET: Retrieve projects
// ==========================================
exports.getAllProjects = async (req, res) => {
    try {
        const { status, search } = req.query;
        let query = "SELECT * FROM projects WHERE 1=1";
        const params = [];

        if (status) {
            query += " AND status = ?";
            params.push(status);
        }
        if (search) {
            query += " AND (project_name LIKE ? OR description LIKE ?)";
            params.push(`%${search}%`, `%${search}%`);
        }

        query += " ORDER BY id DESC";

        const [rows] = await db.query(query, params);
        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

exports.getProjectById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query("SELECT * FROM projects WHERE id = ?", [id]);

        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: `Project with id ${id} not found` });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 2. POST: Create a project
// ==========================================
exports.createProject = async (req, res) => {
    try {
        const { project_name, description, start_date, end_date, budget, status } = req.body;

        if (!project_name) {
            return res.status(400).json({ success: false, message: "project_name is required" });
        }

        const sql = `INSERT INTO projects 
            (project_name, description, start_date, end_date, budget, status) 
            VALUES (?, ?, ?, ?, ?, ?)`;

        const [result] = await db.query(sql, [
            project_name,
            description || null,
            start_date || null,
            end_date || null,
            budget || 0.00,
            status || "Planning"
        ]);

        const [newRecord] = await db.query("SELECT * FROM projects WHERE id = ?", [result.insertId]);

        res.location(`/api/projects/${result.insertId}`);
        res.status(201).json({
            success: true,
            message: "Project created successfully",
            data: newRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 3. PUT: Full replacement/update of project
// ==========================================
exports.updateProjectFull = async (req, res) => {
    try {
        const { id } = req.params;
        const { project_name, description, start_date, end_date, budget, status } = req.body;

        if (!project_name) {
            return res.status(400).json({
                success: false,
                message: "PUT requires all entity fields. project_name is required."
            });
        }

        const [existing] = await db.query("SELECT id FROM projects WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Project with id ${id} not found` });
        }

        const sql = `UPDATE projects SET 
            project_name = ?, description = ?, start_date = ?, end_date = ?, budget = ?, status = ?
            WHERE id = ?`;

        await db.query(sql, [
            project_name,
            description || null,
            start_date || null,
            end_date || null,
            budget || 0.00,
            status || "Planning",
            id
        ]);

        const [updatedRecord] = await db.query("SELECT * FROM projects WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: "Project fully updated successfully (PUT)",
            data: updatedRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 4. PATCH: Partial update of project
// ==========================================
exports.updateProjectPartial = async (req, res) => {
    try {
        const { id } = req.params;
        const fields = req.body;

        if (!fields || Object.keys(fields).length === 0) {
            return res.status(400).json({ success: false, message: "Provide at least one field to update" });
        }

        const [existing] = await db.query("SELECT * FROM projects WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Project with id ${id} not found` });
        }

        const allowedColumns = ["project_name", "description", "start_date", "end_date", "budget", "status"];
        const updates = [];
        const values = [];

        for (const [key, value] of Object.entries(fields)) {
            if (allowedColumns.includes(key)) {
                updates.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (updates.length === 0) {
            return res.status(400).json({ success: false, message: "No valid fields provided for update" });
        }

        values.push(id);
        const sql = `UPDATE projects SET ${updates.join(", ")} WHERE id = ?`;

        await db.query(sql, values);

        const [updatedRecord] = await db.query("SELECT * FROM projects WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: "Project partially updated successfully (PATCH)",
            updated_fields: Object.keys(fields),
            data: updatedRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 5. DELETE: Remove project by ID
// ==========================================
exports.deleteProject = async (req, res) => {
    try {
        const { id } = req.params;
        const [existing] = await db.query("SELECT * FROM projects WHERE id = ?", [id]);

        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Project with id ${id} not found` });
        }

        await db.query("DELETE FROM projects WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: `Project with id ${id} deleted successfully`,
            deleted_project: existing[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 6. HEAD: Headers only
// ==========================================
exports.headAllProjects = async (req, res) => {
    try {
        const [[countResult]] = await db.query("SELECT COUNT(*) AS total FROM projects");
        res.set({
            "Content-Type": "application/json; charset=utf-8",
            "X-Total-Count": countResult.total,
            "X-Resource-Type": "Collection",
            "X-Entity": "projects"
        });
        res.status(200).end();
    } catch (err) {
        res.status(500).end();
    }
};

exports.headProjectById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query("SELECT id, updated_at FROM projects WHERE id = ?", [id]);

        if (rows.length === 0) {
            return res.status(404).end();
        }

        res.set({
            "Content-Type": "application/json; charset=utf-8",
            "X-Resource-ID": id,
            "X-Entity": "projects",
            "Last-Modified": new Date(rows[0].updated_at || Date.now()).toUTCString()
        });
        res.status(200).end();
    } catch (err) {
        res.status(500).end();
    }
};

// ==========================================
// 7. OPTIONS: Describe permitted methods
// ==========================================
exports.optionsCollection = (req, res) => {
    res.set({
        "Allow": "GET, POST, HEAD, OPTIONS",
        "Access-Control-Allow-Methods": "GET, POST, HEAD, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    });
    res.status(204).end();
};

exports.optionsItem = (req, res) => {
    res.set({
        "Allow": "GET, PUT, PATCH, DELETE, HEAD, OPTIONS",
        "Access-Control-Allow-Methods": "GET, PUT, PATCH, DELETE, HEAD, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    });
    res.status(204).end();
};
