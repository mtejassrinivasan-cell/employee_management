const db = require("../config/db").promise();

// ==========================================
// 1. GET: Retrieve all employees or by ID
// ==========================================
exports.getAllEmployees = async (req, res) => {
    try {
        const { department, status, search } = req.query;
        let query = "SELECT * FROM employees WHERE 1=1";
        const params = [];

        if (department) {
            query += " AND department = ?";
            params.push(department);
        }
        if (status) {
            query += " AND status = ?";
            params.push(status);
        }
        if (search) {
            query += " AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)";
            params.push(`%${search}%`, `%${search}%`, `%${search}%`);
        }

        query += " ORDER BY id DESC";

        const [rows] = await db.query(query, params);
        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

exports.getEmployeeById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query("SELECT * FROM employees WHERE id = ?", [id]);

        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: `Employee with id ${id} not found` });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 2. POST: Create a new employee
// ==========================================
exports.createEmployee = async (req, res) => {
    try {
        const { first_name, last_name, email, phone, department, position, salary, hire_date, status } = req.body;

        // Validation for required fields
        if (!first_name || !last_name || !email || !department || !position || salary === undefined || !hire_date) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields: first_name, last_name, email, department, position, salary, hire_date"
            });
        }

        const sql = `INSERT INTO employees 
            (first_name, last_name, email, phone, department, position, salary, hire_date, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

        const [result] = await db.query(sql, [
            first_name,
            last_name,
            email,
            phone || null,
            department,
            position,
            salary,
            hire_date,
            status || "Active"
        ]);

        const [newRecord] = await db.query("SELECT * FROM employees WHERE id = ?", [result.insertId]);

        res.location(`/api/employees/${result.insertId}`);
        res.status(201).json({
            success: true,
            message: "Employee created successfully",
            data: newRecord[0]
        });
    } catch (err) {
        if (err.code === "ER_DUP_ENTRY") {
            return res.status(409).json({ success: false, message: "An employee with this email already exists" });
        }
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 3. PUT: Full replacement/update of employee
// ==========================================
exports.updateEmployeeFull = async (req, res) => {
    try {
        const { id } = req.params;
        const { first_name, last_name, email, phone, department, position, salary, hire_date, status } = req.body;

        // For PUT, all required resource fields must be supplied
        if (!first_name || !last_name || !email || !department || !position || salary === undefined || !hire_date) {
            return res.status(400).json({
                success: false,
                message: "PUT requires all entity fields: first_name, last_name, email, department, position, salary, hire_date"
            });
        }

        const [existing] = await db.query("SELECT id FROM employees WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Employee with id ${id} not found` });
        }

        const sql = `UPDATE employees SET 
            first_name = ?, last_name = ?, email = ?, phone = ?, 
            department = ?, position = ?, salary = ?, hire_date = ?, status = ?
            WHERE id = ?`;

        await db.query(sql, [
            first_name,
            last_name,
            email,
            phone || null,
            department,
            position,
            salary,
            hire_date,
            status || "Active",
            id
        ]);

        const [updatedRecord] = await db.query("SELECT * FROM employees WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: "Employee fully updated successfully (PUT)",
            data: updatedRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 4. PATCH: Partial update of specific fields
// ==========================================
exports.updateEmployeePartial = async (req, res) => {
    try {
        const { id } = req.params;
        const fields = req.body;

        if (!fields || Object.keys(fields).length === 0) {
            return res.status(400).json({ success: false, message: "Provide at least one field to update" });
        }

        const [existing] = await db.query("SELECT * FROM employees WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Employee with id ${id} not found` });
        }

        // Whitelist allowed fields to prevent arbitrary column injection
        const allowedColumns = [
            "first_name", "last_name", "email", "phone", 
            "department", "position", "salary", "hire_date", "status"
        ];

        const updates = [];
        const values = [];

        for (const [key, value] of Object.entries(fields)) {
            if (allowedColumns.includes(key)) {
                updates.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (updates.length === 0) {
            return res.status(400).json({ success: false, message: "No valid fields provided for update" });
        }

        values.push(id);
        const sql = `UPDATE employees SET ${updates.join(", ")} WHERE id = ?`;

        await db.query(sql, values);

        const [updatedRecord] = await db.query("SELECT * FROM employees WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: "Employee partially updated successfully (PATCH)",
            updated_fields: Object.keys(fields),
            data: updatedRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 5. DELETE: Remove employee by ID
// ==========================================
exports.deleteEmployee = async (req, res) => {
    try {
        const { id } = req.params;
        const [existing] = await db.query("SELECT * FROM employees WHERE id = ?", [id]);

        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Employee with id ${id} not found` });
        }

        await db.query("DELETE FROM employees WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: `Employee with id ${id} deleted successfully`,
            deleted_employee: existing[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 6. HEAD: Return headers only (no response body)
// ==========================================
exports.headAllEmployees = async (req, res) => {
    try {
        const [[countResult]] = await db.query("SELECT COUNT(*) AS total FROM employees");
        res.set({
            "Content-Type": "application/json; charset=utf-8",
            "X-Total-Count": countResult.total,
            "X-Resource-Type": "Collection",
            "X-Entity": "employees"
        });
        res.status(200).end();
    } catch (err) {
        res.status(500).end();
    }
};

exports.headEmployeeById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query("SELECT id, updated_at FROM employees WHERE id = ?", [id]);

        if (rows.length === 0) {
            return res.status(404).end();
        }

        res.set({
            "Content-Type": "application/json; charset=utf-8",
            "X-Resource-ID": id,
            "X-Entity": "employees",
            "Last-Modified": new Date(rows[0].updated_at || Date.now()).toUTCString()
        });
        res.status(200).end();
    } catch (err) {
        res.status(500).end();
    }
};

// ==========================================
// 7. OPTIONS: Describe permitted HTTP methods
// ==========================================
exports.optionsCollection = (req, res) => {
    res.set({
        "Allow": "GET, POST, HEAD, OPTIONS",
        "Access-Control-Allow-Methods": "GET, POST, HEAD, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    });
    res.status(204).end();
};

exports.optionsItem = (req, res) => {
    res.set({
        "Allow": "GET, PUT, PATCH, DELETE, HEAD, OPTIONS",
        "Access-Control-Allow-Methods": "GET, PUT, PATCH, DELETE, HEAD, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    });
    res.status(204).end();
};
