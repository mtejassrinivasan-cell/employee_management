const db = require("../config/db").promise();

// =========================================================================
// 1. EMPLOYEE SELF-VIEW: View My Progress, Gaps & Performance Analysis
// =========================================================================
exports.getMyProgress = async (req, res) => {
    try {
        const employeeId = req.user.employee_id;

        if (!employeeId) {
            return res.status(400).json({
                success: false,
                message: "Logged-in user is not linked to an employee record"
            });
        }

        // Fetch consolidated performance and gap analyses for this employee
        const [analyses] = await db.query(`
            SELECT epa.*,
                   p.project_name,
                   CONCAT(evaluator.first_name, ' ', evaluator.last_name) AS evaluator_name,
                   evaluator.position AS evaluator_role
            FROM employee_performance_analysis epa
            JOIN projects p ON epa.project_id = p.id
            JOIN employees evaluator ON epa.evaluator_id = evaluator.id
            WHERE epa.employee_id = ?
            ORDER BY epa.created_at DESC
        `, [employeeId]);

        // Fetch task evaluation breakdown
        const [taskReviews] = await db.query(`
            SELECT t.id AS task_id, t.title, t.status, t.due_date, t.completed_at,
                   p.project_name,
                   te.quality_score, te.timeliness_score, te.efficiency_score, te.manager_notes,
                   CONCAT(evaluator.first_name, ' ', evaluator.last_name) AS evaluated_by_name
            FROM tasks t
            JOIN projects p ON t.project_id = p.id
            LEFT JOIN task_evaluations te ON t.id = te.task_id
            LEFT JOIN employees evaluator ON te.evaluated_by = evaluator.id
            WHERE t.employee_id = ?
            ORDER BY t.due_date DESC
        `, [employeeId]);

        res.status(200).json({
            success: true,
            access_type: "Read-Only (Employee Self-View)",
            employee_id: employeeId,
            analysis_reports_count: analyses.length,
            reports: analyses.map(r => ({
                id: r.id,
                project: r.project_name,
                evaluator: `${r.evaluator_name} (${r.evaluator_role})`,
                evaluation_period: `${r.evaluation_period_start} to ${r.evaluation_period_end}`,
                overall_rating: parseFloat(r.overall_rating),
                strengths: r.strengths,
                where_employee_lacks: r.areas_of_deficiency, // Key requested field
                identified_skill_gaps: r.skill_gaps,
                actionable_remedy_plan: r.actionable_remedy_plan,
                status: r.status,
                last_updated: r.updated_at
            })),
            task_evaluations: taskReviews
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// =========================================================================
// 2. EMPLOYEE SELF-VIEW: Dynamic Task Analytics & Metrics Engine
// =========================================================================
exports.getMyTaskMetrics = async (req, res) => {
    try {
        const employeeId = req.user.employee_id;

        if (!employeeId) {
            return res.status(400).json({ success: false, message: "User is not linked to an employee record" });
        }

        // Fetch all tasks for analytics calculation
        const [tasks] = await db.query(`
            SELECT t.*, te.quality_score, te.timeliness_score, te.efficiency_score
            FROM tasks t
            LEFT JOIN task_evaluations te ON t.id = te.task_id
            WHERE t.employee_id = ?
        `, [employeeId]);

        const totalTasks = tasks.length;
        const completedTasks = tasks.filter(t => t.status === "Completed");
        const pendingTasks = tasks.filter(t => t.status === "Pending" || t.status === "In Progress");

        // Overdue tasks calculation
        const today = new Date();
        const overdueTasks = tasks.filter(t => {
            if (!t.due_date) return false;
            const due = new Date(t.due_date);
            return (t.status !== "Completed" && due < today) || (t.completed_at && new Date(t.completed_at) > due);
        });

        // On-time completions
        const onTimeCompletions = completedTasks.filter(t => {
            if (!t.due_date || !t.completed_at) return true;
            return new Date(t.completed_at) <= new Date(t.due_date);
        });

        // Average scores
        const evaluated = tasks.filter(t => t.quality_score !== null);
        const avgQuality = evaluated.length > 0 
            ? (evaluated.reduce((acc, t) => acc + parseFloat(t.quality_score), 0) / evaluated.length).toFixed(1)
            : "N/A";
        const avgTimeliness = evaluated.length > 0 
            ? (evaluated.reduce((acc, t) => acc + parseFloat(t.timeliness_score), 0) / evaluated.length).toFixed(1)
            : "N/A";
        const avgEfficiency = evaluated.length > 0 
            ? (evaluated.reduce((acc, t) => acc + parseFloat(t.efficiency_score), 0) / evaluated.length).toFixed(1)
            : "N/A";

        const completionRate = totalTasks > 0 ? ((completedTasks.length / totalTasks) * 100).toFixed(1) : 0;
        const onTimeRate = completedTasks.length > 0 ? ((onTimeCompletions.length / completedTasks.length) * 100).toFixed(1) : 0;

        res.status(200).json({
            success: true,
            employee_id: employeeId,
            metrics: {
                total_assigned_tasks: totalTasks,
                completed_tasks: completedTasks.length,
                pending_tasks: pendingTasks.length,
                overdue_or_delayed_tasks: overdueTasks.length,
                completion_rate_percentage: `${completionRate}%`,
                on_time_delivery_rate: `${onTimeRate}%`,
                average_scores: {
                    quality_score: avgQuality,
                    timeliness_score: avgTimeliness,
                    efficiency_score: avgEfficiency
                }
            },
            areas_needing_attention: overdueTasks.map(t => ({
                task_id: t.id,
                title: t.title,
                status: t.status,
                due_date: t.due_date,
                completed_at: t.completed_at,
                issue: t.status !== "Completed" ? "Past deadline and incomplete" : "Delivered past due date"
            }))
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// =========================================================================
// 3. TEAM LEAD / MANAGER: Evaluate an Individual Task Execution
// =========================================================================
exports.evaluateTask = async (req, res) => {
    try {
        const taskId = req.params.taskId;
        const { quality_score, timeliness_score, efficiency_score, manager_notes } = req.body;

        if (quality_score === undefined || timeliness_score === undefined || efficiency_score === undefined) {
            return res.status(400).json({
                success: false,
                message: "Missing required scores: quality_score, timeliness_score, efficiency_score (1.0 to 5.0)"
            });
        }

        // Fetch task and check manager authority
        const [taskRows] = await db.query("SELECT * FROM tasks WHERE id = ?", [taskId]);
        if (taskRows.length === 0) {
            return res.status(404).json({ success: false, message: `Task #${taskId} not found` });
        }
        const task = taskRows[0];

        // Check if evaluator is Lead/Manager of this project
        if (req.user.role !== "Admin") {
            const [membership] = await db.query(`
                SELECT project_role FROM project_members 
                WHERE project_id = ? AND employee_id = ? AND project_role IN ('Manager', 'Lead')
            `, [task.project_id, req.user.employee_id]);

            if (membership.length === 0) {
                return res.status(403).json({
                    success: false,
                    message: "Forbidden: You are not the Team Lead or Project Manager for this task's project"
                });
            }
        }

        // Insert or update task evaluation
        const sql = `
            INSERT INTO task_evaluations 
            (task_id, evaluated_by, quality_score, timeliness_score, efficiency_score, manager_notes)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            evaluated_by = VALUES(evaluated_by),
            quality_score = VALUES(quality_score),
            timeliness_score = VALUES(timeliness_score),
            efficiency_score = VALUES(efficiency_score),
            manager_notes = VALUES(manager_notes),
            evaluated_at = CURRENT_TIMESTAMP
        `;

        await db.query(sql, [
            taskId,
            req.user.employee_id,
            quality_score,
            timeliness_score,
            efficiency_score,
            manager_notes || null
        ]);

        const [evalRows] = await db.query("SELECT * FROM task_evaluations WHERE task_id = ?", [taskId]);

        res.status(200).json({
            success: true,
            message: "Task evaluated successfully by Team Lead / Manager",
            evaluation: evalRows[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// =========================================================================
// 4. TEAM LEAD / MANAGER: Create Employee Performance & Gap Analysis
// =========================================================================
exports.createAnalysis = async (req, res) => {
    try {
        const {
            employee_id,
            project_id,
            evaluation_period_start,
            evaluation_period_end,
            strengths,
            areas_of_deficiency, // Where the employee lacks progress
            skill_gaps,
            actionable_remedy_plan,
            overall_rating,
            status
        } = req.body;

        if (!employee_id || !project_id || !strengths || !areas_of_deficiency || overall_rating === undefined) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields: employee_id, project_id, strengths, areas_of_deficiency, overall_rating"
            });
        }

        const sql = `
            INSERT INTO employee_performance_analysis
            (employee_id, project_id, evaluator_id, evaluation_period_start, evaluation_period_end, 
             strengths, areas_of_deficiency, skill_gaps, actionable_remedy_plan, overall_rating, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const [result] = await db.query(sql, [
            employee_id,
            project_id,
            req.user.employee_id, // Authenticated Team Lead / PM
            evaluation_period_start || new Date().toISOString().split("T")[0],
            evaluation_period_end || new Date().toISOString().split("T")[0],
            strengths,
            areas_of_deficiency,
            skill_gaps || null,
            actionable_remedy_plan || null,
            overall_rating,
            status || "Published"
        ]);

        const [newRecord] = await db.query("SELECT * FROM employee_performance_analysis WHERE id = ?", [result.insertId]);

        res.status(201).json({
            success: true,
            message: "Employee performance and gap analysis created successfully",
            data: newRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// =========================================================================
// 5. TEAM LEAD / MANAGER: Edit / Update Gap Analysis (PUT/PATCH)
// =========================================================================
exports.updateAnalysis = async (req, res) => {
    try {
        const analysisId = req.params.analysisId;
        const [existingRows] = await db.query("SELECT * FROM employee_performance_analysis WHERE id = ?", [analysisId]);

        if (existingRows.length === 0) {
            return res.status(404).json({ success: false, message: `Analysis #${analysisId} not found` });
        }

        const existing = existingRows[0];

        // Ensure user is Team Lead/Manager on that project (or Admin)
        if (req.user.role !== "Admin") {
            const [membership] = await db.query(`
                SELECT project_role FROM project_members 
                WHERE project_id = ? AND employee_id = ? AND project_role IN ('Manager', 'Lead')
            `, [existing.project_id, req.user.employee_id]);

            if (membership.length === 0) {
                return res.status(403).json({
                    success: false,
                    message: "Forbidden: You are not authorized to edit analysis for this project"
                });
            }
        }

        const fields = req.body;
        const allowedColumns = [
            "strengths", "areas_of_deficiency", "skill_gaps", 
            "actionable_remedy_plan", "overall_rating", "status",
            "evaluation_period_start", "evaluation_period_end"
        ];

        const updates = [];
        const values = [];

        for (const [key, value] of Object.entries(fields)) {
            if (allowedColumns.includes(key)) {
                updates.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (updates.length === 0) {
            return res.status(400).json({ success: false, message: "No valid fields provided for update" });
        }

        values.push(analysisId);
        await db.query(`UPDATE employee_performance_analysis SET ${updates.join(", ")} WHERE id = ?`, values);

        const [updatedRows] = await db.query("SELECT * FROM employee_performance_analysis WHERE id = ?", [analysisId]);

        res.status(200).json({
            success: true,
            message: "Performance & gap analysis updated successfully by Lead/Manager",
            data: updatedRows[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// =========================================================================
// 6. TEAM LEAD / MANAGER: View Team Progress & Gaps Across a Project
// =========================================================================
exports.getProjectTeamAnalysis = async (req, res) => {
    try {
        const projectId = req.params.projectId;

        const [analyses] = await db.query(`
            SELECT epa.*,
                   CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                   e.position,
                   e.department,
                   CONCAT(eval.first_name, ' ', eval.last_name) AS evaluator_name
            FROM employee_performance_analysis epa
            JOIN employees e ON epa.employee_id = e.id
            JOIN employees eval ON epa.evaluator_id = eval.id
            WHERE epa.project_id = ?
            ORDER BY epa.created_at DESC
        `, [projectId]);

        res.status(200).json({
            success: true,
            project_id: projectId,
            team_analysis_count: analyses.length,
            team_reports: analyses
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// =========================================================================
// 7. TEAM LEAD / MANAGER / ADMIN: Delete Analysis Report
// =========================================================================
exports.deleteAnalysis = async (req, res) => {
    try {
        const analysisId = req.params.analysisId;
        const [existing] = await db.query("SELECT * FROM employee_performance_analysis WHERE id = ?", [analysisId]);

        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Analysis #${analysisId} not found` });
        }

        await db.query("DELETE FROM employee_performance_analysis WHERE id = ?", [analysisId]);

        res.status(200).json({
            success: true,
            message: `Performance analysis #${analysisId} deleted successfully`
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};
