const db = require("../config/db").promise();

// ==========================================
// 1. GET: Retrieve performance reviews
// ==========================================
exports.getAllReviews = async (req, res) => {
    try {
        const { employee_id, min_rating } = req.query;
        let query = `
            SELECT pr.*, 
                   CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                   e.department,
                   e.position
            FROM performance_reviews pr
            JOIN employees e ON pr.employee_id = e.id
            WHERE 1=1
        `;
        const params = [];

        if (employee_id) {
            query += " AND pr.employee_id = ?";
            params.push(employee_id);
        }
        if (min_rating) {
            query += " AND pr.rating >= ?";
            params.push(min_rating);
        }

        query += " ORDER BY pr.review_date DESC";

        const [rows] = await db.query(query, params);
        res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

exports.getReviewById = async (req, res) => {
    try {
        const { id } = req.params;
        const query = `
            SELECT pr.*, 
                   CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                   e.department,
                   e.position
            FROM performance_reviews pr
            JOIN employees e ON pr.employee_id = e.id
            WHERE pr.id = ?
        `;
        const [rows] = await db.query(query, [id]);

        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: `Performance review with id ${id} not found` });
        }

        res.status(200).json({
            success: true,
            data: rows[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 2. POST: Create a new performance review
// ==========================================
exports.createReview = async (req, res) => {
    try {
        const { employee_id, reviewer_name, review_date, rating, feedback, goals } = req.body;

        if (!employee_id || !reviewer_name || !review_date || rating === undefined) {
            return res.status(400).json({
                success: false,
                message: "Missing required fields: employee_id, reviewer_name, review_date, rating"
            });
        }

        const sql = `INSERT INTO performance_reviews 
            (employee_id, reviewer_name, review_date, rating, feedback, goals) 
            VALUES (?, ?, ?, ?, ?, ?)`;

        const [result] = await db.query(sql, [
            employee_id,
            reviewer_name,
            review_date,
            rating,
            feedback || null,
            goals || null
        ]);

        const [newRecord] = await db.query("SELECT * FROM performance_reviews WHERE id = ?", [result.insertId]);

        res.location(`/api/performance/${result.insertId}`);
        res.status(201).json({
            success: true,
            message: "Performance review created successfully",
            data: newRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 3. PUT: Full replacement/update of review
// ==========================================
exports.updateReviewFull = async (req, res) => {
    try {
        const { id } = req.params;
        const { employee_id, reviewer_name, review_date, rating, feedback, goals } = req.body;

        if (!employee_id || !reviewer_name || !review_date || rating === undefined) {
            return res.status(400).json({
                success: false,
                message: "PUT requires all entity fields: employee_id, reviewer_name, review_date, rating"
            });
        }

        const [existing] = await db.query("SELECT id FROM performance_reviews WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Performance review with id ${id} not found` });
        }

        const sql = `UPDATE performance_reviews SET 
            employee_id = ?, reviewer_name = ?, review_date = ?, rating = ?, feedback = ?, goals = ?
            WHERE id = ?`;

        await db.query(sql, [
            employee_id,
            reviewer_name,
            review_date,
            rating,
            feedback || null,
            goals || null,
            id
        ]);

        const [updatedRecord] = await db.query("SELECT * FROM performance_reviews WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: "Performance review fully updated successfully (PUT)",
            data: updatedRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 4. PATCH: Partial update of review
// ==========================================
exports.updateReviewPartial = async (req, res) => {
    try {
        const { id } = req.params;
        const fields = req.body;

        if (!fields || Object.keys(fields).length === 0) {
            return res.status(400).json({ success: false, message: "Provide at least one field to update" });
        }

        const [existing] = await db.query("SELECT * FROM performance_reviews WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Performance review with id ${id} not found` });
        }

        const allowedColumns = ["employee_id", "reviewer_name", "review_date", "rating", "feedback", "goals"];
        const updates = [];
        const values = [];

        for (const [key, value] of Object.entries(fields)) {
            if (allowedColumns.includes(key)) {
                updates.push(`${key} = ?`);
                values.push(value);
            }
        }

        if (updates.length === 0) {
            return res.status(400).json({ success: false, message: "No valid fields provided for update" });
        }

        values.push(id);
        const sql = `UPDATE performance_reviews SET ${updates.join(", ")} WHERE id = ?`;

        await db.query(sql, values);

        const [updatedRecord] = await db.query("SELECT * FROM performance_reviews WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: "Performance review partially updated successfully (PATCH)",
            updated_fields: Object.keys(fields),
            data: updatedRecord[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 5. DELETE: Remove performance review
// ==========================================
exports.deleteReview = async (req, res) => {
    try {
        const { id } = req.params;
        const [existing] = await db.query("SELECT * FROM performance_reviews WHERE id = ?", [id]);

        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: `Performance review with id ${id} not found` });
        }

        await db.query("DELETE FROM performance_reviews WHERE id = ?", [id]);

        res.status(200).json({
            success: true,
            message: `Performance review with id ${id} deleted successfully`,
            deleted_review: existing[0]
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 6. HEAD: Return headers only
// ==========================================
exports.headAllReviews = async (req, res) => {
    try {
        const [[countResult]] = await db.query("SELECT COUNT(*) AS total FROM performance_reviews");
        res.set({
            "Content-Type": "application/json; charset=utf-8",
            "X-Total-Count": countResult.total,
            "X-Resource-Type": "Collection",
            "X-Entity": "performance_reviews"
        });
        res.status(200).end();
    } catch (err) {
        res.status(500).end();
    }
};

exports.headReviewById = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query("SELECT id, updated_at FROM performance_reviews WHERE id = ?", [id]);

        if (rows.length === 0) {
            return res.status(404).end();
        }

        res.set({
            "Content-Type": "application/json; charset=utf-8",
            "X-Resource-ID": id,
            "X-Entity": "performance_reviews",
            "Last-Modified": new Date(rows[0].updated_at || Date.now()).toUTCString()
        });
        res.status(200).end();
    } catch (err) {
        res.status(500).end();
    }
};

// ==========================================
// 7. OPTIONS: Describe permitted methods
// ==========================================
exports.optionsCollection = (req, res) => {
    res.set({
        "Allow": "GET, POST, HEAD, OPTIONS",
        "Access-Control-Allow-Methods": "GET, POST, HEAD, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    });
    res.status(204).end();
};

exports.optionsItem = (req, res) => {
    res.set({
        "Allow": "GET, PUT, PATCH, DELETE, HEAD, OPTIONS",
        "Access-Control-Allow-Methods": "GET, PUT, PATCH, DELETE, HEAD, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    });
    res.status(204).end();
};
