const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

async function seed() {
    try {
        const conn = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: 'MySQL@123',
            database: 'employee_db',
            multipleStatements: true
        });

        console.log('Connected to MySQL. Migrating schema...');

        // Add completed_at column to tasks if missing
        try {
            await conn.query("ALTER TABLE tasks ADD COLUMN completed_at DATE NULL AFTER due_date");
        } catch (e) {
            // column already exists, ignore
        }

        const sqlPath = path.join(__dirname, '..', 'DB_EMPLOYEE.sql');
        const sql = fs.readFileSync(sqlPath, 'utf8');
        await conn.query(sql);
        console.log('Schema applied successfully.');

        const users = [
            { empId: 1, user: 'john_doe', role: 'Employee', pass: 'password123' },
            { empId: 2, user: 'jane_smith', role: 'Employee', pass: 'password123' },
            { empId: 3, user: 'robert_lead', role: 'Team_Lead', pass: 'password123' },
            { empId: 4, user: 'emily_manager', role: 'Project_Manager', pass: 'password123' },
            { empId: null, user: 'admin_user', role: 'Admin', pass: 'admin123' }
        ];

        for (const u of users) {
            const hash = await bcrypt.hash(u.pass, 10);
            await conn.query(
                `INSERT INTO users (employee_id, username, password_hash, role)
                 VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), role = VALUES(role)`,
                [u.empId, u.user, hash, u.role]
            );
        }

        console.log('Users seeded with secure bcrypt hashes!');
        await conn.end();
    } catch (err) {
        console.error('Seed error:', err.message);
        process.exit(1);
    }
}

seed();
