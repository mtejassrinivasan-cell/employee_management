const express = require("express");
const cors = require("cors");
require("dotenv").config();

const db = require("./config/db");

// Import route modules
const employeeRoutes = require("./node_routes/employee_routes");
const projectRoutes = require("./node_routes/project_routes");
const taskRoutes = require("./node_routes/task_routes");
const performanceRoutes = require("./node_routes/performance_routes");
const authRoutes = require("./node_routes/auth_routes");
const analysisRoutes = require("./node_routes/analysis_routes");

const app = express();

// Middleware
app.use(cors({
    origin: "*",
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "Accept", "X-Requested-With"]
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logger for debugging HTTP methods
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
    next();
});

const path = require("path");
app.use(express.static(path.join(__dirname, "public")));

// API Directory / Interactive Studio
app.get("/", (req, res) => {
    if (req.accepts("html")) {
        return res.sendFile(path.join(__dirname, "public", "index.html"));
    }
    res.json({
        message: "Employee Performance API is running",
        supported_methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
        endpoints: {
            employees: "/api/employees",
            projects: "/api/projects",
            tasks: "/api/tasks",
            performance: "/api/performance",
            test_db: "/api/test-db"
        }
    });
});

// Database connectivity check
app.get("/api/test-db", (req, res) => {
    if (!db || typeof db.query !== "function") {
        return res.status(500).json({
            success: false,
            error: "Database configuration is not properly initialized"
        });
    }

    db.query("SELECT 1 AS result, DATABASE() as db_name", (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: "Database connection failed",
                error: err.message,
                tip: "Make sure MySQL is running and check DB credentials in .env"
            });
        }

        res.json({
            success: true,
            message: "Database connected successfully",
            database: result[0].db_name,
            result: result
        });
    });
});

// Mount Resource Routes
app.use("/api/employees", employeeRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/performance", performanceRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/analysis", analysisRoutes);

// 404 Handler for undefined routes
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: `Endpoint ${req.method} ${req.originalUrl} not found`
    });
});

// Global Error Handler
app.use((err, req, res, next) => {
    console.error("Unhandled Error:", err);
    res.status(err.status || 500).json({
        success: false,
        error: err.message || "Internal Server Error"
    });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
    console.log(`📡 Ready to handle GET, POST, PUT, PATCH, DELETE, HEAD, and OPTIONS requests!`);
});
