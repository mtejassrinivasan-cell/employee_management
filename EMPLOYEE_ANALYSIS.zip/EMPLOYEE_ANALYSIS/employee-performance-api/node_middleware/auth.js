const jwt = require("jsonwebtoken");
const db = require("../config/db").promise();

// ==========================================
// 1. Verify JWT Authentication Token
// ==========================================
exports.authenticateToken = (req, res, next) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.startsWith("Bearer ") ? authHeader.split(" ")[1] : null;

    if (!token) {
        return res.status(401).json({
            success: false,
            message: "Authentication required: Please provide a valid Bearer token in Authorization header"
        });
    }

    jwt.verify(token, process.env.JWT_SECRET || "super_secret_employee_portal_jwt_key_2026", (err, decoded) => {
        if (err) {
            return res.status(403).json({
                success: false,
                message: "Invalid or expired token"
            });
        }

        req.user = decoded; // { id, employee_id, username, role }
        next();
    });
};

// ==========================================
// 2. Role Authorization Middleware
// ==========================================
exports.requireRoles = (...roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: `Forbidden: Access requires one of the following roles: [${roles.join(", ")}]. Your role is: ${req.user ? req.user.role : "Anonymous"}`
            });
        }
        next();
    };
};

// ==========================================
// 3. Project Scope Authority Check (Lead/Manager must manage the project)
// ==========================================
exports.requireProjectLeadOrManager = async (req, res, next) => {
    try {
        if (req.user.role === "Admin") {
            return next();
        }

        if (!["Team_Lead", "Project_Manager"].includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: "Forbidden: Only Team Leads or Project Managers can perform this operation"
            });
        }

        const projectId = req.body.project_id || req.params.projectId || req.query.project_id;

        if (!projectId) {
            return res.status(400).json({
                success: false,
                message: "project_id is required to verify manager/lead authority"
            });
        }

        // Check if current user is Lead or Manager in this project
        const [membership] = await db.query(`
            SELECT project_role 
            FROM project_members 
            WHERE project_id = ? AND employee_id = ? AND project_role IN ('Manager', 'Lead')
        `, [projectId, req.user.employee_id]);

        if (membership.length === 0) {
            return res.status(403).json({
                success: false,
                message: `Forbidden: You are not assigned as Team Lead or Project Manager on project #${projectId}`
            });
        }

        next();
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};

// ==========================================
// 4. Employee Self-Access or Manager Oversight
// ==========================================
exports.requireSelfOrLeadManager = async (req, res, next) => {
    try {
        if (req.user.role === "Admin" || ["Team_Lead", "Project_Manager"].includes(req.user.role)) {
            return next();
        }

        // For regular employees: can only access their own employee ID
        const targetEmployeeId = parseInt(req.params.employeeId || req.query.employee_id || req.body.employee_id, 10);

        if (req.user.role === "Employee" && targetEmployeeId && targetEmployeeId !== req.user.employee_id) {
            return res.status(403).json({
                success: false,
                message: "Forbidden: Employees are strictly restricted to viewing only their own analysis and progress"
            });
        }

        next();
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};
