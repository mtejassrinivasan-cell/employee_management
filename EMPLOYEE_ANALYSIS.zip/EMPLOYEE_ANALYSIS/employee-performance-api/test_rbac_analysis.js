const http = require('http');

function apiCall(method, path, data = null, token = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3000,
            path: path,
            method: method,
            headers: {
                'Accept': 'application/json'
            }
        };
        if (token) {
            options.headers['Authorization'] = `Bearer ${token}`;
        }
        if (data) {
            const bodyStr = JSON.stringify(data);
            options.headers['Content-Type'] = 'application/json';
            options.headers['Content-Length'] = Buffer.byteLength(bodyStr);
        }
        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                let parsed = null;
                try {
                    parsed = JSON.parse(body);
                } catch (e) {
                    parsed = body;
                }
                resolve({
                    status: res.statusCode,
                    body: parsed
                });
            });
        });
        req.on('error', reject);
        if (data) req.write(JSON.stringify(data));
        req.end();
    });
}

(async () => {
    console.log("==========================================================================");
    console.log("TESTING EMPLOYEE TASK PROGRESS, DEFICIENCY & RBAC PORTAL (BACKEND)");
    console.log("==========================================================================\n");

    // 1. Employee Login
    console.log("1️⃣  Logging in as Employee ('john_doe')...");
    const empLogin = await apiCall('POST', '/api/auth/login', {
        username: 'john_doe',
        password: 'password123'
    });
    console.log(`   Status: ${empLogin.status} | Role: ${empLogin.body.user.role}`);
    const empToken = empLogin.body.token;

    // 2. Employee views their own progress & where they lack
    console.log("\n2️⃣  Employee ('john_doe') viewing their progress & gap analysis report...");
    const empProgress = await apiCall('GET', '/api/analysis/my-progress', null, empToken);
    console.log(`   Status: ${empProgress.status} | Reports count: ${empProgress.body.analysis_reports_count}`);
    const report = empProgress.body.reports[0];
    console.log(`   - Evaluator: ${report.evaluator}`);
    console.log(`   - Strengths: ${report.strengths}`);
    console.log(`   - WHERE EMPLOYEE LACKS: ${report.where_employee_lacks}`);
    console.log(`   - Skill Gaps: ${report.identified_skill_gaps}`);
    console.log(`   - Actionable Remedy Plan: ${report.actionable_remedy_plan}`);

    // 3. Employee views task metrics
    console.log("\n3️⃣  Employee ('john_doe') viewing dynamic task metrics & bottlenecks...");
    const empMetrics = await apiCall('GET', '/api/analysis/my-task-metrics', null, empToken);
    console.log(`   Status: ${empMetrics.status}`);
    console.log(`   - Completion Rate: ${empMetrics.body.metrics.completion_rate_percentage}`);
    console.log(`   - On-Time Delivery Rate: ${empMetrics.body.metrics.on_time_delivery_rate}`);
    console.log(`   - Average Quality Score: ${empMetrics.body.metrics.average_scores.quality_score}/5.0`);
    console.log(`   - Overdue/Delayed Tasks: ${empMetrics.body.metrics.overdue_or_delayed_tasks}`);

    // 4. Employee attempts to EDIT their own analysis report (Should be FORBIDDEN)
    console.log("\n4️⃣  Employee ('john_doe') attempts to edit their report via PUT /api/analysis/1...");
    const illegalEdit = await apiCall('PUT', '/api/analysis/1', {
        areas_of_deficiency: "I have no weaknesses!"
    }, empToken);
    console.log(`   Status: ${illegalEdit.status} (Expected 403 Forbidden)`);
    console.log(`   Server Response: ${illegalEdit.body.message}`);

    // 5. Team Lead Login
    console.log("\n5️⃣  Logging in as Team Lead ('robert_lead')...");
    const leadLogin = await apiCall('POST', '/api/auth/login', {
        username: 'robert_lead',
        password: 'password123'
    });
    console.log(`   Status: ${leadLogin.status} | Role: ${leadLogin.body.user.role}`);
    const leadToken = leadLogin.body.token;

    // 6. Team Lead evaluates a task
    console.log("\n6️⃣  Team Lead evaluating Task #1 ('Build Authentication Module')...");
    const taskEval = await apiCall('POST', '/api/analysis/tasks/1/evaluate', {
        quality_score: 4.9,
        timeliness_score: 5.0,
        efficiency_score: 4.8,
        manager_notes: "Top-tier execution on JWT auth and RBAC."
    }, leadToken);
    console.log(`   Status: ${taskEval.status} | Message: ${taskEval.body.message}`);

    // 7. Team Lead edits / updates employee progress analysis
    console.log("\n7️⃣  Team Lead updating Employee #1's analysis report (PUT /api/analysis/1)...");
    const leadUpdate = await apiCall('PUT', '/api/analysis/1', {
        areas_of_deficiency: "Improved in SQL indexing, still needs practice in query execution plan optimization.",
        overall_rating: 4.2
    }, leadToken);
    console.log(`   Status: ${leadUpdate.status} | Message: ${leadUpdate.body.message}`);
    console.log(`   New Deficiency Note: ${leadUpdate.body.data.areas_of_deficiency}`);
    console.log(`   New Overall Rating: ${leadUpdate.body.data.overall_rating}/5.0`);

    // 8. Team Lead views team analysis across project
    console.log("\n8️⃣  Team Lead viewing team progress & gaps for Project #1...");
    const teamReport = await apiCall('GET', '/api/analysis/project/1/team', null, leadToken);
    console.log(`   Status: ${teamReport.status} | Total Team Reports: ${teamReport.body.team_analysis_count}`);

    console.log("\n==========================================================================");
    console.log("🎉 ALL PERMISSIONS, ROLES, AND GAP ANALYSIS LOGIC VERIFIED 100%!");
    console.log("==========================================================================");
})();
