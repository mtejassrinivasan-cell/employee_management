const express = require("express");
const router = express.Router();
const employeeController = require("../node_controllers/employee_controller");

// Route for collection endpoints (/api/employees)
router.route("/")
    .get(employeeController.getAllEmployees)
    .post(employeeController.createEmployee)
    .head(employeeController.headAllEmployees)
    .options(employeeController.optionsCollection);

// Route for individual resource endpoints (/api/employees/:id)
router.route("/:id")
    .get(employeeController.getEmployeeById)
    .put(employeeController.updateEmployeeFull)
    .patch(employeeController.updateEmployeePartial)
    .delete(employeeController.deleteEmployee)
    .head(employeeController.headEmployeeById)
    .options(employeeController.optionsItem);

module.exports = router;
