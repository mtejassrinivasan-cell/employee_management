const express = require("express");
const router = express.Router();
const authController = require("../node_controllers/auth_controller");
const { authenticateToken, requireRoles } = require("../node_middleware/auth");

// Public authentication endpoint
router.post("/login", authController.login);

// Protected user management (Admin only)
router.post("/register", authenticateToken, requireRoles("Admin"), authController.register);

// Protected profile endpoint
router.get("/me", authenticateToken, authController.getMe);

module.exports = router;
