const express = require("express");
const router = express.Router();
const analysisController = require("../node_controllers/analysis_controller");
const { 
    authenticateToken, 
    requireRoles, 
    requireProjectLeadOrManager 
} = require("../node_middleware/auth");

// All analysis endpoints require an active JWT session
router.use(authenticateToken);

// =========================================================================
// 1. EMPLOYEE SELF-VIEW ENDPOINTS (Read-only for authenticated employee)
// =========================================================================

// Employee views their own performance and where they lack
router.get("/my-progress", analysisController.getMyProgress);

// Employee views their dynamic task execution metrics & bottlenecks
router.get("/my-task-metrics", analysisController.getMyTaskMetrics);


// =========================================================================
// 2. TEAM LEAD & PROJECT MANAGER OPERATIONS (Write & Edit Permissions)
// =========================================================================

// Team Lead / Manager evaluates an individual task's execution quality
router.post(
    "/tasks/:taskId/evaluate",
    requireRoles("Team_Lead", "Project_Manager", "Admin"),
    analysisController.evaluateTask
);

// Team Lead / Manager creates comprehensive performance & lack analysis
router.post(
    "/",
    requireRoles("Team_Lead", "Project_Manager", "Admin"),
    requireProjectLeadOrManager,
    analysisController.createAnalysis
);

// Team Lead / Manager updates/edits performance & gap analysis (PUT / PATCH)
router.route("/:analysisId")
    .put(
        requireRoles("Team_Lead", "Project_Manager", "Admin"),
        analysisController.updateAnalysis
    )
    .patch(
        requireRoles("Team_Lead", "Project_Manager", "Admin"),
        analysisController.updateAnalysis
    )
    .delete(
        requireRoles("Team_Lead", "Project_Manager", "Admin"),
        analysisController.deleteAnalysis
    );

// Team Lead / Manager views overall team progress & gaps for a project
router.get(
    "/project/:projectId/team",
    requireRoles("Team_Lead", "Project_Manager", "Admin"),
    analysisController.getProjectTeamAnalysis
);

module.exports = router;
