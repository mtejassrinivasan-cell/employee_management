const express = require("express");
const router = express.Router();
const taskController = require("../node_controllers/tasks_controller");

// /api/tasks
router.route("/")
    .get(taskController.getAllTasks)
    .post(taskController.createTask)
    .head(taskController.headAllTasks)
    .options(taskController.optionsCollection);

// /api/tasks/:id
router.route("/:id")
    .get(taskController.getTaskById)
    .put(taskController.updateTaskFull)
    .patch(taskController.updateTaskPartial)
    .delete(taskController.deleteTask)
    .head(taskController.headTaskById)
    .options(taskController.optionsItem);

module.exports = router;
