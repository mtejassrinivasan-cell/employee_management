const express = require("express");
const router = express.Router();
const projectController = require("../node_controllers/project_controller");

// /api/projects
router.route("/")
    .get(projectController.getAllProjects)
    .post(projectController.createProject)
    .head(projectController.headAllProjects)
    .options(projectController.optionsCollection);

// /api/projects/:id
router.route("/:id")
    .get(projectController.getProjectById)
    .put(projectController.updateProjectFull)
    .patch(projectController.updateProjectPartial)
    .delete(projectController.deleteProject)
    .head(projectController.headProjectById)
    .options(projectController.optionsItem);

module.exports = router;
