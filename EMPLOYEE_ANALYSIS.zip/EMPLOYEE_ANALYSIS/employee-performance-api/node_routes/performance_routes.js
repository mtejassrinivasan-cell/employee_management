const express = require("express");
const router = express.Router();
const performanceController = require("../node_controllers/performance_controller");

// /api/performance
router.route("/")
    .get(performanceController.getAllReviews)
    .post(performanceController.createReview)
    .head(performanceController.headAllReviews)
    .options(performanceController.optionsCollection);

// /api/performance/:id
router.route("/:id")
    .get(performanceController.getReviewById)
    .put(performanceController.updateReviewFull)
    .patch(performanceController.updateReviewPartial)
    .delete(performanceController.deleteReview)
    .head(performanceController.headReviewById)
    .options(performanceController.optionsItem);

module.exports = router;
