# =====================================================================
# EMPLOYEE PERFORMANCE API - AUTOMATED 7-METHOD TEST SUITE (POWERSHELL)
# Tests: GET, POST, PUT, PATCH, DELETE, HEAD, and OPTIONS
# =====================================================================

$baseUrl = "http://localhost:3000/api/employees"
Write-Host "`n>>> Running Employee Performance API 7-Method Test Suite...`n" -ForegroundColor Cyan

# 1. GET (Retrieve all employees)
Write-Host "[1/7] Testing GET $baseUrl" -ForegroundColor Yellow
try {
    $res = Invoke-RestMethod -Uri $baseUrl -Method Get -UseBasicParsing
    Write-Host "   Status: 200 OK | Count: $($res.count)" -ForegroundColor Green
    $firstEmpId = $res.data[0].id
} catch {
    Write-Host "   GET Failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# 2. HEAD (Retrieve headers only)
Write-Host "`n[2/7] Testing HEAD $baseUrl" -ForegroundColor Yellow
try {
    $headRes = Invoke-WebRequest -Uri $baseUrl -Method Head -UseBasicParsing
    $totalCount = $headRes.Headers["X-Total-Count"]
    Write-Host "   Status: 200 OK | X-Total-Count: $totalCount" -ForegroundColor Green
} catch {
    Write-Host "   HEAD Failed: $($_.Exception.Message)" -ForegroundColor Red
}

# 3. OPTIONS (Check allowed HTTP methods and CORS)
Write-Host "`n[3/7] Testing OPTIONS $baseUrl" -ForegroundColor Yellow
try {
    $optRes = Invoke-WebRequest -Uri $baseUrl -Method Options -UseBasicParsing
    $allowed = $optRes.Headers["Access-Control-Allow-Methods"]
    Write-Host "   Status: $($optRes.StatusCode) | Allowed Methods: $allowed" -ForegroundColor Green
} catch {
    Write-Host "   OPTIONS Failed: $($_.Exception.Message)" -ForegroundColor Red
}

# 4. POST (Create a new employee)
Write-Host "`n[4/7] Testing POST $baseUrl" -ForegroundColor Yellow
$timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$newEmployee = @{
    first_name = "Alex"
    last_name  = "Morgan"
    email      = "alex.morgan.$timestamp@example.com"
    phone      = "9876543233"
    department = "Engineering"
    position   = "Backend Engineer"
    salary     = 72000
    hire_date  = "2024-03-01"
} | ConvertTo-Json

try {
    $postRes = Invoke-RestMethod -Uri $baseUrl -Method Post -ContentType "application/json" -Body $newEmployee -UseBasicParsing
    $createdId = $postRes.data.id
    Write-Host "   Status: 201 Created | Created Employee ID: $createdId" -ForegroundColor Green
    Write-Host "   Name: $($postRes.data.first_name) $($postRes.data.last_name) | Position: $($postRes.data.position)" -ForegroundColor Gray
} catch {
    Write-Host "   POST Failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# 5. PATCH (Partial update - update salary and position only)
Write-Host "`n[5/7] Testing PATCH $baseUrl/$createdId" -ForegroundColor Yellow
$patchBody = @{
    salary   = 82000
    position = "Senior Backend Engineer"
} | ConvertTo-Json

try {
    $patchRes = Invoke-RestMethod -Uri "$baseUrl/$createdId" -Method Patch -ContentType "application/json" -Body $patchBody -UseBasicParsing
    Write-Host "   Status: 200 OK | Partial Update Successful" -ForegroundColor Green
    Write-Host "   Updated Position: $($patchRes.data.position) | New Salary: $($patchRes.data.salary)" -ForegroundColor Gray
} catch {
    Write-Host "   PATCH Failed: $($_.Exception.Message)" -ForegroundColor Red
}

# 6. PUT (Full update - update entire employee record)
Write-Host "`n[6/7] Testing PUT $baseUrl/$createdId" -ForegroundColor Yellow
$putBody = @{
    first_name = "Alexander"
    last_name  = "Morgan"
    email      = "alex.morgan.$timestamp@example.com"
    phone      = "9876543233"
    department = "Cloud Architecture"
    position   = "Lead Cloud Architect"
    salary     = 105000
    hire_date  = "2024-03-01"
    status     = "Active"
} | ConvertTo-Json

try {
    $putRes = Invoke-RestMethod -Uri "$baseUrl/$createdId" -Method Put -ContentType "application/json" -Body $putBody -UseBasicParsing
    Write-Host "   Status: 200 OK | Full Update Successful" -ForegroundColor Green
    Write-Host "   Full Update Title: $($putRes.data.position) | Dept: $($putRes.data.department)" -ForegroundColor Gray
} catch {
    Write-Host "   PUT Failed: $($_.Exception.Message)" -ForegroundColor Red
}

# 7. DELETE (Delete the created employee)
Write-Host "`n[7/7] Testing DELETE $baseUrl/$createdId" -ForegroundColor Yellow
try {
    $delRes = Invoke-RestMethod -Uri "$baseUrl/$createdId" -Method Delete -UseBasicParsing
    Write-Host "   Status: 200 OK | Message: $($delRes.message)" -ForegroundColor Green
} catch {
    Write-Host "   DELETE Failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n========================================================" -ForegroundColor DarkGray
Write-Host "ALL 7 HTTP METHODS EXECUTED AND VERIFIED SUCCESSFULLY!" -ForegroundColor Green
Write-Host "========================================================`n" -ForegroundColor DarkGray
