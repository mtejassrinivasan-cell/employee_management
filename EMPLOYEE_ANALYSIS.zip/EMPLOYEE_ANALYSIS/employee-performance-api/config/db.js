const mysql = require("mysql2");
require("dotenv").config();

const pool = mysql.createPool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "employee_db",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Non-blocking connection check on startup
pool.getConnection((err, connection) => {
    if (err) {
        console.warn("⚠️ [MySQL] Connection warning:", err.message);
        console.warn("ℹ️  Make sure MySQL is running and DB credentials in .env (DB_PASSWORD, DB_NAME) are configured.");
    } else {
        console.log("✅ [MySQL] Database connected successfully to:", process.env.DB_NAME || "employee_db");
        connection.release();
    }
});

module.exports = pool;
