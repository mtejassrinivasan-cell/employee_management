-- ============================================================
-- EMPLOYEE PERFORMANCE & ANALYSIS DATABASE SCHEMA
-- ============================================================

CREATE DATABASE IF NOT EXISTS employee_db;
USE employee_db;

-- 1. EMPLOYEES TABLE
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    department VARCHAR(50) NOT NULL,
    position VARCHAR(50) NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    hire_date DATE NOT NULL,
    status ENUM('Active', 'Inactive', 'On Leave') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 2. PROJECTS TABLE
CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_name VARCHAR(100) NOT NULL,
    description TEXT,
    start_date DATE,
    end_date DATE,
    budget DECIMAL(12, 2) DEFAULT 0.00,
    status ENUM('Planning', 'In Progress', 'Completed', 'On Hold') DEFAULT 'Planning',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 3. TASKS TABLE
CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    employee_id INT,
    project_id INT,
    priority ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'Medium',
    status ENUM('Pending', 'In Progress', 'Completed', 'Cancelled') DEFAULT 'Pending',
    due_date DATE,
    completed_at DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- 4. PERFORMANCE REVIEWS TABLE
CREATE TABLE IF NOT EXISTS performance_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    reviewer_name VARCHAR(100) NOT NULL,
    review_date DATE NOT NULL,
    rating DECIMAL(3, 1) NOT NULL,
    feedback TEXT,
    goals TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- 5. USERS & RBAC TABLE
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNIQUE NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Employee', 'Team_Lead', 'Project_Manager', 'Admin') DEFAULT 'Employee',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- 6. PROJECT ASSIGNMENTS & HIERARCHY
CREATE TABLE IF NOT EXISTS project_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    employee_id INT NOT NULL,
    project_role ENUM('Manager', 'Lead', 'Member') DEFAULT 'Member',
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE KEY unique_project_member (project_id, employee_id)
);

-- 7. TASK EVALUATIONS (How well the employee performed each task)
CREATE TABLE IF NOT EXISTS task_evaluations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT UNIQUE NOT NULL,
    evaluated_by INT NOT NULL, -- TL or PM employee ID
    quality_score DECIMAL(3, 1) NOT NULL, -- 1.0 to 5.0
    timeliness_score DECIMAL(3, 1) NOT NULL, -- 1.0 to 5.0
    efficiency_score DECIMAL(3, 1) NOT NULL, -- 1.0 to 5.0
    manager_notes TEXT,
    evaluated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
    FOREIGN KEY (evaluated_by) REFERENCES employees(id)
);

-- 8. EMPLOYEE PERFORMANCE & PROGRESS GAP ANALYSIS
CREATE TABLE IF NOT EXISTS employee_performance_analysis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    project_id INT NOT NULL,
    evaluator_id INT NOT NULL, -- TL or PM employee ID
    evaluation_period_start DATE NOT NULL,
    evaluation_period_end DATE NOT NULL,
    
    -- Analysis Dimensions
    strengths TEXT NOT NULL,                   -- What the employee did well
    areas_of_deficiency TEXT NOT NULL,         -- Where the employee lacks progress / weaknesses
    skill_gaps TEXT,                           -- Specific technical or domain skills missing
    actionable_remedy_plan TEXT,               -- Steps, training, or guidance to overcome lack
    
    overall_rating DECIMAL(3, 1) NOT NULL,     -- Weighted score (1.0 to 5.0)
    status ENUM('Draft', 'Published') DEFAULT 'Published',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (evaluator_id) REFERENCES employees(id)
);

-- ============================================================
-- SEED SAMPLE DATA
-- ============================================================

INSERT INTO employees (id, first_name, last_name, email, phone, department, position, salary, hire_date, status)
VALUES
(1, 'John', 'Doe', 'john.doe@example.com', '9876543210', 'Engineering', 'Full Stack Developer', 75000.00, '2023-01-15', 'Active'),
(2, 'Jane', 'Smith', 'jane.smith@example.com', '9876543211', 'Marketing', 'Marketing Lead', 68000.00, '2022-06-10', 'Active'),
(3, 'Robert', 'Johnson', 'robert.j@example.com', '9876543212', 'Engineering', 'Tech Lead', 95000.00, '2021-09-01', 'Active'),
(4, 'Emily', 'Davis', 'emily.davis@example.com', '9876543213', 'Product', 'Project Manager', 110000.00, '2020-03-20', 'Active'),
(5, 'Michael', 'Brown', 'michael.b@example.com', '9876543214', 'Sales', 'Account Executive', 58000.00, '2024-02-01', 'On Leave')
ON DUPLICATE KEY UPDATE email=email;

INSERT INTO projects (id, project_name, description, start_date, end_date, budget, status)
VALUES
(1, 'HR Portal Redesign', 'Internal HR portal modern dashboard', '2024-01-10', '2024-06-30', 45000.00, 'In Progress'),
(2, 'Cloud Migration', 'Migrate on-premise infrastructure to AWS', '2023-11-01', '2024-05-15', 90000.00, 'In Progress')
ON DUPLICATE KEY UPDATE project_name=project_name;

-- Project Members (Emily is PM, Robert is TL, John & Jane are members)
INSERT INTO project_members (project_id, employee_id, project_role)
VALUES
(1, 4, 'Manager'), -- Emily (PM)
(1, 3, 'Lead'),    -- Robert (TL)
(1, 1, 'Member'),  -- John (Employee)
(2, 4, 'Manager'), -- Emily (PM)
(2, 3, 'Lead'),    -- Robert (TL)
(2, 2, 'Member')   -- Jane (Employee)
ON DUPLICATE KEY UPDATE project_role=project_role;

-- Tasks
INSERT INTO tasks (id, title, description, employee_id, project_id, priority, status, due_date, completed_at)
VALUES
(1, 'Build Authentication Module', 'Implement JWT & RBAC login flow', 1, 1, 'High', 'Completed', '2024-02-15', '2024-02-14'),
(2, 'Develop Task Analytics Engine', 'Calculate progress & skill deficiency metrics', 1, 1, 'Critical', 'Completed', '2024-03-01', '2024-03-05'),
(3, 'Setup Terraform AWS Infrastructure', 'VPC, ECS, and RDS scripts', 3, 2, 'Critical', 'In Progress', '2024-04-10', NULL)
ON DUPLICATE KEY UPDATE title=title;

-- Task Evaluations (Evaluated by Robert, Tech Lead)
INSERT INTO task_evaluations (task_id, evaluated_by, quality_score, timeliness_score, efficiency_score, manager_notes)
VALUES
(1, 3, 4.8, 5.0, 4.7, 'Excellent architectural structure and secure token signing.'),
(2, 3, 3.5, 2.5, 3.8, 'Delivered 4 days late due to struggle with complex SQL aggregation. Core logic is good but needs query optimization.')
ON DUPLICATE KEY UPDATE quality_score=quality_score;

-- Consolidated Performance & Gap Analysis
INSERT INTO employee_performance_analysis 
(employee_id, project_id, evaluator_id, evaluation_period_start, evaluation_period_end, strengths, areas_of_deficiency, skill_gaps, actionable_remedy_plan, overall_rating, status)
VALUES
(
    1, 1, 3, '2024-01-01', '2024-03-31',
    'Demonstrates high competency in Express.js API design, clean code patterns, and JWT authentication.',
    'Lacks speed when implementing complex SQL analytical queries. Tends to fall behind deadlines on data-intensive tasks without proactively communicating roadblocks.',
    'Advanced MySQL indexing, window functions, and time-estimation for non-trivial queries.',
    '1. Enroll in Advanced Relational Database Design course. 2. Pair program with Tech Lead on complex queries for next 3 sprints. 3. Daily standup status updates on task blockers.',
    3.8, 'Published'
)
ON DUPLICATE KEY UPDATE overall_rating=overall_rating;
